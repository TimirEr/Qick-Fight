//LOGIN FÖR API (MÅSTE GÖRA SÅ ATT DEN ÄR GIT IGNORE)

const BASE_URL="https://mmaapi.p.rapidapi.com/";
const API_KEY="5fcae92888msh27b07a13601f6bfp19cec4jsn2dfbc7b5ab9d";

export {BASE_URL,API_KEY};