import showresultView from "../views/showresultView";


export default observer(
    
    function Showresult(){
    return <showresultView></showresultView>
})