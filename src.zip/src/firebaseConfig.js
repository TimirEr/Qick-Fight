// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyDlCmp149q7ZHTakem6Sg_lsyASUEpX4pQ",
    authDomain: "quickfight.firebaseapp.com",
    databaseURL: "https://quickfight-default-rtdb.europe-west1.firebasedatabase.app/",
    projectId: "quickfight",
    storageBucket: "quickfight.appspot.com",
    messagingSenderId: "842757669436",
    appId: "1:842757669436:web:c2b254d65225cf877d3939",
    measurementId: "G-7G4CXRQ298"
  };
